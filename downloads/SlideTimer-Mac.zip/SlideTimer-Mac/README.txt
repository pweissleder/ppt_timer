SLIDE TIMER 1.2.4 — POWERPOINT FOR MAC

Start by opening START-HERE.html in this folder. The screenshot guide and preview work offline.

The powerpoint folder contains BOTH files to import into your presentation:
  SlideTimer.bas
  SlideTimerEvents.cls

Save your presentation as .pptm. Add both files once per presentation,
then run Timer_Insert to choose a duration and sound. Start the show normally
and click the timer's play/pause button or digits.

Workshop tip: duplicate your Action slide and add the timer to the copy.
Resize it as you like by selecting the whole group and dragging a corner.

The powerpoint/paste folder has the alternative code for copy-and-paste setup.
The docs folder contains setup, usage, troubleshooting and update guides.
